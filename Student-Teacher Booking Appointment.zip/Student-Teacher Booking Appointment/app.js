// =============================
// LocalStorage App "Database"
// =============================
const DB_KEYS = {
  USERS: 'st_users',
  TEACHERS: 'st_teachers',
  SLOTS: 'st_slots',
  APPOINTMENTS: 'st_appointments',
  MESSAGES: 'st_messages',
  LOGS: 'st_audit_logs',
  SESSION: 'st_session',
  SETTINGS: 'st_settings'
};

// Initialize logging (loglevel)
const logger = window.log || console;
if (window.log) {
  const savedLevel = JSON.parse(localStorage.getItem(DB_KEYS.SETTINGS) || '{}').logLevel || 'info';
  window.log.setLevel(savedLevel);
}

// Util: read/write LS
const read = (key, fallback=[]) => JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));
const write = (key, val) => localStorage.setItem(key, JSON.stringify(val));

// Util: id
const uid = (prefix='id') => prefix + '_' + Math.random().toString(36).slice(2,9);

// Util: ts
const nowISO = () => new Date().toISOString();

// Seed admin if needed
(function seedAdmin(){
  const users = read(DB_KEYS.USERS);
  const hasAdmin = users.some(u => u.role==='admin');
  if (!hasAdmin){
    users.push({ id: uid('u'), role:'admin', username:'admin', password:'admin', name:'System Admin'});
    write(DB_KEYS.USERS, users);
    audit(null, 'seed_admin', {username:'admin'});
    logger.info('Admin seeded: admin/admin');
  }
})();

// =============================
// AUDIT LOGGING
// =============================
function audit(userId, action, details={}){
  const logs = read(DB_KEYS.LOGS);
  logs.push({ id: uid('log'), ts: nowISO(), userId, action, details });
  write(DB_KEYS.LOGS, logs);
  if (window.log) window.log.info('[AUDIT]', action, details);
}

// =============================
// Auth / Session
// =============================
function setSession(user){
  write(DB_KEYS.SESSION, user ? { id:user.id, role:user.role, username:user.username, name:user.name } : null);
  document.getElementById('current-user-label').textContent = user ? `${user.role.toUpperCase()}: ${user.username}` : 'Not logged in';
  document.getElementById('btn-logout').classList.toggle('hidden', !user);
}

function currentUser(){
  const s = read(DB_KEYS.SESSION, null);
  return s;
}

document.getElementById('btn-logout').addEventListener('click', ()=>{
  const user = currentUser();
  if (user) audit(user.id, 'logout', {});
  setSession(null);
  document.getElementById('dashboards').classList.add('hidden');
  document.querySelector('.auth-section').classList.remove('hidden');
});

// =============================
// Tabs (auth role switcher)
// =============================
document.querySelectorAll('.tab-btn').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    const tab = btn.dataset.tab;
    document.querySelectorAll('.tab-body').forEach(t=>t.classList.add('hidden'));
    document.getElementById('tab-'+tab).classList.remove('hidden');
  });
});

// =============================
// Helpers: Renderers
// =============================
function renderTable(containerId, headers, rows){
  const el = document.getElementById(containerId);
  if (!rows.length){
    el.innerHTML = `<div class="muted" style="padding:12px">No records</div>`;
    return;
  }
  let thead = '<tr>' + headers.map(h=>`<th>${h}</th>`).join('') + '</tr>';
  let tbody = rows.map(r=> '<tr>'+ r.map(c=>`<td>${c}</td>`).join('') + '</tr>').join('');
  el.innerHTML = `<table><thead>${thead}</thead><tbody>${tbody}</tbody></table>`;
}

function humanDateTime(iso){
  const d = new Date(iso);
  return d.toLocaleString();
}

// =============================
// STUDENT: Register + Login
// =============================
document.getElementById('student-register-form').addEventListener('submit', (e)=>{
  e.preventDefault();
  const name = document.getElementById('stu-name').value.trim();
  const username = document.getElementById('stu-username').value.trim();
  const password = document.getElementById('stu-password').value;
  const email = document.getElementById('stu-email').value.trim();

  const users = read(DB_KEYS.USERS);
  if (users.some(u=>u.username===username)){
    alert('Username taken. Choose another.');
    return;
  }

  const student = { id: uid('u'), role:'student', username, password, name, email, approved:false };
  users.push(student);
  write(DB_KEYS.USERS, users);
  audit(student.id, 'student_register', { username });

  alert('Registered! Await admin approval to login.');
  e.target.reset();
});

document.getElementById('student-login-form').addEventListener('submit', (e)=>{
  e.preventDefault();
  const username = document.getElementById('student-login-username').value.trim();
  const password = document.getElementById('student-login-password').value;
  const users = read(DB_KEYS.USERS);
  const user = users.find(u=>u.username===username && u.password===password && u.role==='student');
  if (!user){
    alert('Invalid credentials.');
    return;
  }
  if (!user.approved){
    alert('Awaiting admin approval.');
    return;
  }
  setSession(user);
  audit(user.id, 'login', { role:'student' });
  openDashboard('student');
  loadStudentData();
});

// =============================
// TEACHER: Login
// =============================
document.getElementById('teacher-login-form').addEventListener('submit', (e)=>{
  e.preventDefault();
  const username = document.getElementById('teacher-login-username').value.trim();
  const password = document.getElementById('teacher-login-password').value;
  const users = read(DB_KEYS.USERS);
  const user = users.find(u=>u.username===username && u.password===password && u.role==='teacher');
  if (!user){
    alert('Invalid credentials.');
    return;
  }
  setSession(user);
  audit(user.id, 'login', { role:'teacher' });
  openDashboard('teacher');
  loadTeacherData();
});

// =============================
// ADMIN: Login
// =============================
document.getElementById('admin-login-form').addEventListener('submit', (e)=>{
  e.preventDefault();
  const username = document.getElementById('admin-login-username').value.trim();
  const password = document.getElementById('admin-login-password').value;
  const users = read(DB_KEYS.USERS);
  const user = users.find(u=>u.username===username && u.password===password && u.role==='admin');
  if (!user){
    alert('Invalid admin credentials.');
    return;
  }
  setSession(user);
  audit(user.id, 'login', { role:'admin' });
  openDashboard('admin');
  loadAdminData();
});

// =============================
// Open dashboards
// =============================
function openDashboard(role){
  document.querySelector('.auth-section').classList.add('hidden');
  document.getElementById('dashboards').classList.remove('hidden');
  document.querySelectorAll('.dashboard').forEach(d=>d.classList.add('hidden'));
  document.getElementById(role+'-dashboard').classList.remove('hidden');
}

// =============================
// ADMIN: Add/Update/Delete Teacher
// =============================
function resetTeacherForm(){
  document.getElementById('teacher-id').value = '';
  document.getElementById('teacher-form').reset();
}

document.getElementById('teacher-reset').addEventListener('click', resetTeacherForm);

document.getElementById('teacher-form').addEventListener('submit', (e)=>{
  e.preventDefault();
  const id = document.getElementById('teacher-id').value || uid('t');
  const name = document.getElementById('teacher-name').value.trim();
  const department = document.getElementById('teacher-dept').value.trim();
  const subject = document.getElementById('teacher-subj').value.trim();
  const username = document.getElementById('teacher-username').value.trim();
  const password = document.getElementById('teacher-password').value;

  const teachers = read(DB_KEYS.TEACHERS);
  const users = read(DB_KEYS.USERS);

  let teacher = teachers.find(t=>t.id===id);
  if (teacher){
    Object.assign(teacher, { name, department, subject, username });
    // update linked teacher user
    const tUser = users.find(u=>u.role==='teacher' && u.teacherId===id);
    if (tUser){ Object.assign(tUser, { username, password }); }
    audit(currentUser()?.id, 'teacher_update', { id, name, department, subject, username });
  } else {
    teacher = { id, name, department, subject, username };
    teachers.push(teacher);
    // create user for teacher
    users.push({ id: uid('u'), role:'teacher', username, password, name, teacherId: id });
    audit(currentUser()?.id, 'teacher_add', { id, name, department, subject, username });
  }

  write(DB_KEYS.TEACHERS, teachers);
  write(DB_KEYS.USERS, users);

  resetTeacherForm();
  loadAdminData();
});

function deleteTeacher(id){
  let teachers = read(DB_KEYS.TEACHERS);
  const teacher = teachers.find(t=>t.id===id);
  if (!teacher) return;
  if (!confirm('Delete this teacher? This also disables their login.')) return;
  teachers = teachers.filter(t=>t.id!==id);
  write(DB_KEYS.TEACHERS, teachers);
  // remove teacher user
  const users = read(DB_KEYS.USERS).filter(u=>!(u.role==='teacher' && u.teacherId===id));
  write(DB_KEYS.USERS, users);
  // remove slots and appointments for the teacher
  const slots = read(DB_KEYS.SLOTS).filter(s=>s.teacherId!==id);
  write(DB_KEYS.SLOTS, slots);
  const appts = read(DB_KEYS.APPOINTMENTS).filter(a=>a.teacherId!==id);
  write(DB_KEYS.APPOINTMENTS, appts);
  audit(currentUser()?.id, 'teacher_delete', { id, name: teacher.name });
  loadAdminData();
}

// Approve Student
function approveStudent(studentId){
  const users = read(DB_KEYS.USERS);
  const stu = users.find(u=>u.id===studentId);
  if (stu){
    stu.approved = true;
    write(DB_KEYS.USERS, users);
    audit(currentUser()?.id, 'student_approve', { studentId });
    loadAdminData();
  }
}

// =============================
// TEACHER: Slots, Appointments, Messages
// =============================
document.getElementById('slot-form').addEventListener('submit', (e)=>{
  e.preventDefault();
  const user = currentUser();
  const date = document.getElementById('slot-date').value;
  const time = document.getElementById('slot-time').value;
  const iso = new Date(date + 'T' + time).toISOString();

  const slots = read(DB_KEYS.SLOTS);
  if (slots.some(s=>s.teacherId===user.id && s.slotTime===iso)){
    alert('Slot already exists.');
    return;
  }
  slots.push({ id: uid('slot'), teacherId: user.id, slotTime: iso, bookedBy: null });
  write(DB_KEYS.SLOTS, slots);
  audit(user.id, 'slot_add', { iso });
  loadTeacherData();
});

function approveAppointment(apptId){
  const appts = read(DB_KEYS.APPOINTMENTS);
  const appt = appts.find(a=>a.id===apptId);
  if (!appt) return;
  appt.status = 'approved';
  write(DB_KEYS.APPOINTMENTS, appts);
  audit(currentUser()?.id, 'appointment_approve', { apptId });
  loadTeacherData();
}

function cancelAppointment(apptId){
  const appts = read(DB_KEYS.APPOINTMENTS);
  const appt = appts.find(a=>a.id===apptId);
  if (!appt) return;
  appt.status = 'cancelled';
  // free slot
  const slots = read(DB_KEYS.SLOTS);
  const slot = slots.find(s=>s.id===appt.slotId);
  if (slot) slot.bookedBy = null;
  write(DB_KEYS.SLOTS, slots);
  write(DB_KEYS.APPOINTMENTS, appts);
  audit(currentUser()?.id, 'appointment_cancel', { apptId });
  loadTeacherData();
}

// =============================
// STUDENT: Search, Book, Message
// =============================
document.getElementById('btn-search-teachers').addEventListener('click', ()=>{
  renderTeacherSearch();
});

document.getElementById('book-form').addEventListener('submit', (e)=>{
  e.preventDefault();
  const user = currentUser();
  const teacherId = document.getElementById('book-teacher').value;
  const slotId = document.getElementById('book-slot').value;
  const purpose = document.getElementById('book-purpose').value.trim();

  const slots = read(DB_KEYS.SLOTS);
  const slot = slots.find(s=>s.id===slotId && !s.bookedBy);
  if (!slot){ alert('Slot not available.'); return; }

  slot.bookedBy = user.id;
  write(DB_KEYS.SLOTS, slots);

  const appts = read(DB_KEYS.APPOINTMENTS);
  appts.push({
    id: uid('appt'),
    slotId,
    teacherId,
    studentId: user.id,
    purpose,
    status: 'pending',
    requestedAt: nowISO()
  });
  write(DB_KEYS.APPOINTMENTS, appts);
  audit(user.id, 'appointment_book', { teacherId, slotId });

  alert('Appointment requested! Await teacher approval.');
  loadStudentData();
});

document.getElementById('stu-message-form').addEventListener('submit', (e)=>{
  e.preventDefault();
  const user = currentUser();
  const to = document.getElementById('stu-msg-to').value;
  const text = document.getElementById('stu-msg-text').value.trim();
  if (!text) return;
  const msgs = read(DB_KEYS.MESSAGES);
  msgs.push({ id: uid('msg'), from: user.id, to, text, ts: nowISO() });
  write(DB_KEYS.MESSAGES, msgs);
  audit(user.id, 'message_send', { to });
  e.target.reset();
  loadStudentMessages();
});

// =============================
// LOADERS
// =============================
function loadAdminData(){
  // teachers table
  const teachers = read(DB_KEYS.TEACHERS);
  renderTable('admin-teacher-table',
    ['Name','Department','Subject','Username','Actions'],
    teachers.map(t=>[
      t.name, t.department, t.subject, t.username,
      `<button class="btn small" onclick="editTeacher('${t.id}')">Edit</button>
       <button class="btn small outline" onclick="deleteTeacher('${t.id}')">Delete</button>`
    ])
  );

  // pending students
  const users = read(DB_KEYS.USERS);
  const pending = users.filter(u=>u.role==='student' && !u.approved);
  renderTable('pending-students',
    ['Name','Username','Email','Action'],
    pending.map(s=>[ s.name, s.username, s.email, `<button class="btn small" onclick="approveStudent('${s.id}')">Approve</button>` ])
  );

  // logs
  const logs = read(DB_KEYS.LOGS).slice().reverse().slice(0, 200);
  renderTable('audit-logs',
    ['Time','User','Action','Details'],
    logs.map(l=>[ humanDateTime(l.ts), l.userId || '-', l.action, `<pre style="white-space:pre-wrap;margin:0">${JSON.stringify(l.details,null,0)}</pre>` ])
  );

  // log level
  const settings = JSON.parse(localStorage.getItem(DB_KEYS.SETTINGS) || '{}');
  document.getElementById('log-level').value = settings.logLevel || 'info';
}

function editTeacher(id){
  const t = read(DB_KEYS.TEACHERS).find(x=>x.id===id);
  if (!t) return;
  document.getElementById('teacher-id').value = t.id;
  document.getElementById('teacher-name').value = t.name;
  document.getElementById('teacher-dept').value = t.department;
  document.getElementById('teacher-subj').value = t.subject;
  document.getElementById('teacher-username').value = t.username;
  // find teacher user's password to show (not secure; demo only)
  const tUser = read(DB_KEYS.USERS).find(u=>u.role==='teacher' && u.teacherId===id);
  document.getElementById('teacher-password').value = tUser?.password || '';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function loadTeacherData(){
  const user = currentUser();
  const mySlots = read(DB_KEYS.SLOTS).filter(s=>s.teacherId===user.id);
  const openSlots = mySlots.filter(s=>!s.bookedBy);
  renderTable('teacher-open-slots',
    ['Date/Time','Actions'],
    openSlots.map(s=>[ humanDateTime(s.slotTime), `<span class="badge ok">OPEN</span>` ])
  );

  const appts = read(DB_KEYS.APPOINTMENTS).filter(a=>a.teacherId===user.id);
  const users = read(DB_KEYS.USERS);
  renderTable('teacher-appointments',
    ['When','Student','Purpose','Status','Actions'],
    appts.map(a=>{
      const slot = read(DB_KEYS.SLOTS).find(s=>s.id===a.slotId);
      const stu = users.find(u=>u.id===a.studentId);
      const statusBadge = a.status==='approved' ? 'ok' : (a.status==='cancelled' ? 'err' : 'warn');
      return [
        slot? humanDateTime(slot.slotTime):'-',
        stu? stu.name : '-',
        a.purpose,
        `<span class="badge ${statusBadge}">${a.status.toUpperCase()}</span>`,
        (a.status==='pending'
          ? `<button class="btn small" onclick="approveAppointment('${a.id}')">Approve</button>
             <button class="btn small outline" onclick="cancelAppointment('${a.id}')">Cancel</button>`
          : `<button class="btn small outline" onclick="cancelAppointment('${a.id}')">Cancel</button>`)
      ];
    })
  );

  // messages to me
  const msgs = read(DB_KEYS.MESSAGES).filter(m=>m.to===user.id);
  const usersById = Object.fromEntries(read(DB_KEYS.USERS).map(u=>[u.id,u]));
  const msgHtml = msgs.slice().reverse().map(m=>`<div class="msg"><div>${m.text}</div><small>From: ${usersById[m.from]?.name || m.from} • ${humanDateTime(m.ts)}</small></div>`).join('');
  document.getElementById('teacher-messages').innerHTML = msgHtml || '<div class="muted">No messages</div>';
}

function loadStudentData(){
  populateTeacherOptions();
  renderTeacherSearch();
  loadStudentAppointments();
  loadStudentMessages();
}

function populateTeacherOptions(){
  const teachers = read(DB_KEYS.TEACHERS);
  const sel1 = document.getElementById('book-teacher');
  const sel2 = document.getElementById('stu-msg-to');
  sel1.innerHTML = '<option value="" disabled selected>Select teacher</option>' + teachers.map(t=>`<option value="${getTeacherUserId(t.id)}">${t.name} — ${t.subject}</option>`).join('');
  sel2.innerHTML = '<option value="" disabled selected>Select teacher</option>' + teachers.map(t=>`<option value="${getTeacherUserId(t.id)}">${t.name} — ${t.subject}</option>`).join('');
}

function getTeacherUserId(teacherId){
  const u = read(DB_KEYS.USERS).find(x=>x.role==='teacher' && x.teacherId===teacherId);
  return u?.id || '';
}

let lastSelectedTeacherId = null;

function renderTeacherSearch(){
  const name = document.getElementById('search-name').value.trim().toLowerCase();
  const dept = document.getElementById('search-dept').value.trim().toLowerCase();
  const subj = document.getElementById('search-subj').value.trim().toLowerCase();

  const teachers = read(DB_KEYS.TEACHERS).filter(t=>
    (!name || t.name.toLowerCase().includes(name)) &&
    (!dept || t.department.toLowerCase().includes(dept)) &&
    (!subj || t.subject.toLowerCase().includes(subj))
  );

  renderTable('teacher-results',
    ['Name','Department','Subject','Actions'],
    teachers.map(t=>[
      t.name, t.department, t.subject,
      `<button class="btn small" onclick="selectTeacher('${t.id}')">View Slots</button>`
    ])
  );

  // also update teacher dropdown for booking
  const bookTeacherSel = document.getElementById('book-teacher');
  bookTeacherSel.innerHTML = '<option value="" disabled selected>Select teacher</option>' + teachers.map(t=>`<option value="${getTeacherUserId(t.id)}">${t.name} — ${t.subject}</option>`).join('');
}

function selectTeacher(teacherId){
  lastSelectedTeacherId = teacherId;
  const slots = read(DB_KEYS.SLOTS).filter(s=>s.teacherId===getTeacherUserId(teacherId) || s.teacherId===teacherId); // support both ids
  const openSlots = slots.filter(s=>!s.bookedBy);
  renderTable('available-slots',
    ['Date/Time','Slot Id'],
    openSlots.map(s=>[ humanDateTime(s.slotTime), s.id ])
  );
  const slotSel = document.getElementById('book-slot');
  slotSel.innerHTML = '<option value="" disabled selected>Select slot</option>' + openSlots.map(s=>`<option value="${s.id}">${humanDateTime(s.slotTime)}</option>`).join('');
  const teacherSel = document.getElementById('book-teacher');
  teacherSel.value = getTeacherUserId(teacherId);
}

function loadStudentAppointments(){
  const user = currentUser();
  const appts = read(DB_KEYS.APPOINTMENTS).filter(a=>a.studentId===user.id);
  renderTable('student-appointments',
    ['When','Teacher','Purpose','Status'],
    appts.map(a=>{
      const slot = read(DB_KEYS.SLOTS).find(s=>s.id===a.slotId);
      const teacherUser = read(DB_KEYS.USERS).find(u=>u.id===a.teacherId);
      const teacher = read(DB_KEYS.TEACHERS).find(t=>t.id===teacherUser?.teacherId);
      const statusBadge = a.status==='approved' ? 'ok' : (a.status==='cancelled' ? 'err' : 'warn');
      return [ slot? humanDateTime(slot.slotTime):'-', teacher? teacher.name:'-', a.purpose, `<span class="badge ${statusBadge}">${a.status.toUpperCase()}</span>` ];
    })
  );
}

function loadStudentMessages(){
  const user = currentUser();
  const msgs = read(DB_KEYS.MESSAGES).filter(m=>m.from===user.id || m.to===user.id);
  const usersById = Object.fromEntries(read(DB_KEYS.USERS).map(u=>[u.id,u]));
  const msgHtml = msgs.slice().reverse().map(m=>{
    const dir = m.from===user.id ? 'You → ' + (usersById[m.to]?.name || m.to) : (usersById[m.from]?.name || m.from) + ' → You';
    return `<div class="msg"><div>${m.text}</div><small>${dir} • ${humanDateTime(m.ts)}</small></div>`;
  }).join('');
  document.getElementById('stu-messages').innerHTML = msgHtml || '<div class="muted">No messages</div>';
}

// =============================
// ADMIN: Logs controls
// =============================
document.getElementById('log-level').addEventListener('change', (e)=>{
  const lvl = e.target.value;
  const settings = JSON.parse(localStorage.getItem(DB_KEYS.SETTINGS) || '{}');
  settings.logLevel = lvl;
  write(DB_KEYS.SETTINGS, settings);
  if (window.log) window.log.setLevel(lvl);
  audit(currentUser()?.id, 'log_level_change', { lvl });
  loadAdminData();
});

document.getElementById('btn-clear-logs').addEventListener('click', ()=>{
  if (!confirm('Clear all logs?')) return;
  write(DB_KEYS.LOGS, []);
  audit(currentUser()?.id, 'logs_cleared', {});
  loadAdminData();
});

document.getElementById('btn-export-logs').addEventListener('click', ()=>{
  const data = JSON.stringify(read(DB_KEYS.LOGS), null, 2);
  const blob = new Blob([data], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'audit-logs.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  audit(currentUser()?.id, 'logs_export', {});
});

// =============================
// On load: attempt to restore session
// =============================
(function init(){
  const sess = read(DB_KEYS.SESSION, null);
  setSession(sess);
  if (sess){
    openDashboard(sess.role);
    if (sess.role==='admin') loadAdminData();
    if (sess.role==='teacher') loadTeacherData();
    if (sess.role==='student') loadStudentData();
  }
})();